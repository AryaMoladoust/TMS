"use client";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";

import {
    ArrowRight,
    UserRound,
    Phone,
    MapPin,
    Truck,
    CreditCard,
    CalendarDays,
    Pencil,
    Trash2,
    LoaderCircle,
} from "lucide-react";

import { useNotification } from "@/components/ui/NotificationProvider";

export default function DriverDetailsPage() {
    const params = useParams();
    const router = useRouter();

    const {
        showSuccess,
        showError,
        confirm,
    } = useNotification();

    const [driver, setDriver] = useState(null);
    const [loading, setLoading] = useState(true);
    const [deleting, setDeleting] = useState(false);

    useEffect(() => {
        async function loadDriver() {
            try {
                const response = await fetch(
                    `/api/drivers/${params.id}`
                );

                const data = await response.json();

                if (!response.ok) {
                    throw new Error(
                        data.message ||
                            "خطا در دریافت اطلاعات راننده"
                    );
                }

                setDriver(data.driver);
            } catch (error) {
                console.error(
                    "Load driver error:",
                    error
                );

                showError(
                    error.message ||
                        "خطا در دریافت اطلاعات راننده",
                    "خطا در دریافت راننده"
                );
            } finally {
                setLoading(false);
            }
        }

        if (params.id) {
            loadDriver();
        }
    }, [params.id, showError]);

    async function handleDelete() {
        const confirmed = await confirm({
            title: "حذف راننده",
            message: `آیا از حذف راننده «${
                driver?.name || ""
            }» مطمئن هستید؟ این عملیات قابل بازگشت نیست.`,
            confirmText: "حذف راننده",
            cancelText: "انصراف",
            danger: true,
        });

        if (!confirmed) {
            return;
        }

        try {
            setDeleting(true);

            const response = await fetch(
                `/api/drivers/${params.id}`,
                {
                    method: "DELETE",
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(
                    data.message ||
                        "خطا در حذف راننده"
                );
            }

            showSuccess(
                `راننده «${
                    driver?.name || ""
                }» با موفقیت حذف شد.`,
                "حذف راننده موفق"
            );

            setTimeout(() => {
                router.push("/drivers");
                router.refresh();
            }, 700);
        } catch (error) {
            console.error(
                "Delete driver error:",
                error
            );

            showError(
                error.message ||
                    "خطا در حذف راننده",
                "خطا در حذف راننده"
            );

            setDeleting(false);
        }
    }

    function getVehicleType(type) {
        const types = {
            truck: "کامیون",
            trailer: "تریلی",
            pickup: "نیسان",
            van: "وانت",
        };

        return types[type] || type;
    }

    if (loading) {
        return (
            <main className="main-content">
                <div className="driver-loading">
                    <LoaderCircle
                        size={28}
                        className="loading-spinner"
                    />

                    <span>
                        در حال دریافت اطلاعات راننده...
                    </span>
                </div>
            </main>
        );
    }

    if (!driver) {
        return (
            <main className="main-content">
                <div className="driver-error">
                    <p>
                        اطلاعات راننده قابل دریافت
                        نیست.
                    </p>

                    <Link
                        href="/drivers"
                        className="primary-action-button"
                    >
                        بازگشت به رانندگان
                    </Link>
                </div>
            </main>
        );
    }

    return (
        <main className="main-content">
            <div className="page-heading page-heading-with-action">
                <div>
                    <div className="driver-back-wrap">
                        <Link
                            href="/drivers"
                            className="driver-back-button"
                        >
                            <span className="driver-back-icon">
                                <ArrowRight size={16} />
                            </span>
                            بازگشت به رانندگان
                        </Link>
                    </div>

                    <h1>{driver.name}</h1>

                    <p>
                        مشاهده و مدیریت اطلاعات راننده
                    </p>
                </div>

                <div className="driver-detail-actions">
                    <Link
                        href={`/drivers/${driver._id}/edit`}
                        className="primary-action-button"
                    >
                        <Pencil size={18} />
                        ویرایش راننده
                    </Link>

                    <button
                        type="button"
                        className="driver-delete-button"
                        onClick={handleDelete}
                        disabled={deleting}
                    >
                        {deleting ? (
                            <LoaderCircle
                                size={18}
                                className="loading-spinner"
                            />
                        ) : (
                            <Trash2 size={18} />
                        )}

                        {deleting
                            ? "در حال حذف..."
                            : "حذف راننده"}
                    </button>
                </div>
            </div>

            <section className="driver-detail-panel">
                <div className="driver-detail-header">
                    <div className="driver-detail-avatar">
                        <UserRound size={30} />
                    </div>

                    <div>
                        <h2>{driver.name}</h2>
                    </div>
                </div>

                <div className="driver-detail-grid">
                    <div className="driver-detail-card">
                        <UserRound size={20} />

                        <div>
                            <span>کد ملی</span>

                            <strong>
                                {driver.nationalId}
                            </strong>
                        </div>
                    </div>

                    <div className="driver-detail-card">
                        <Phone size={20} />

                        <div>
                            <span>
                                شماره موبایل
                            </span>

                            <strong>
                                {driver.phone}
                            </strong>
                        </div>
                    </div>

                    <div className="driver-detail-card">
                        <Phone size={20} />

                        <div>
                            <span>تلفن ثابت</span>

                            <strong>
                                {driver.landline ||
                                    "ثبت نشده"}
                            </strong>
                        </div>
                    </div>

                    <div className="driver-detail-card">
                        <Truck size={20} />

                        <div>
                            <span>نوع خودرو</span>

                            <strong>
                                {getVehicleType(
                                    driver.vehicleType
                                )}
                            </strong>
                        </div>
                    </div>

                    <div className="driver-detail-card">
                        <Truck size={20} />

                        <div>
                            <span>شماره پلاک</span>

                            <strong>
                                {driver.vehiclePlate}
                            </strong>
                        </div>
                    </div>

                    <div className="driver-detail-card">
                        <CreditCard size={20} />

                        <div>
                            <span>
                                شماره گواهینامه
                            </span>

                            <strong>
                                {driver.licenseNumber}
                            </strong>
                        </div>
                    </div>

                    <div className="driver-detail-card">
                        <CalendarDays size={20} />

                        <div>
                            <span>
                                اعتبار گواهینامه
                            </span>

                            <strong>
                                {driver.licenseExpiry ||
                                    "ثبت نشده"}
                            </strong>
                        </div>
                    </div>

                    <div className="driver-detail-card">
                        <MapPin size={20} />

                        <div>
                            <span>آدرس</span>

                            <strong>
                                {driver.address ||
                                    "ثبت نشده"}
                            </strong>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    );
}