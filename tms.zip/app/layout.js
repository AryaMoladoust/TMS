import "./globals.css";

import NotificationProvider from "@/components/ui/NotificationProvider";

export const metadata = {
  title: "سرویس حمل‌ونقل باربری",
  description: "سیستم مدیریت حمل‌ونقل باربری",
};

export default function RootLayout({ children }) {
  return (
    <html
      lang="fa"
      dir="rtl"
      suppressHydrationWarning
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function () {
                try {
                  const theme = localStorage.getItem("tms-theme");

                  if (theme === "dark") {
                    document.documentElement.classList.add("dark");
                  }
                } catch (e) {}
              })();
            `,
          }}
        />
      </head>

      <body>
        <NotificationProvider>
          {children}
        </NotificationProvider>
      </body>
    </html>
  );
}